<?php
$url = isset($_GET['url']) ? $_GET['url'] : '';
?>
<body>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="referrer" content="never">
    <title>P2P记忆播放器</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="js/DPlayer.min.css">
    <link rel="stylesheet" href="js/diy1.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style type="text/css">
        body, html, .dplayer {
            padding: 0;
            margin: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            color: #999;
        }

        a {
            text-decoration: none;
            color: #000;
        }

        #a1, #loading, #error {
            padding: 0;
            margin: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            color: #999;
        }
      #stats{position:fixed;top:30px;left:10px;font-size:12px;color:#fdfdfd;z-index:2147483647;text-shadow:1px 1px 1px #000, 1px 1px 1px #000}
    </style>
</head>
<body>
<div id="dplayer" class="dplayer"></div>
<div id="stats" class="hidden-xs"></div>
<script type="text/javascript" src="js/hls.light.min.js"></script>
<script type="text/javascript" src="js/DPlayer.min.js" charset="utf-8"></script>
<script src="js/flv.min.js"></script>
<script type="text/javascript">
    var webdata = {
		set:function(key,val){
			window.sessionStorage.setItem(key,val);
		},
		get:function(key){
			return window.sessionStorage.getItem(key);
		},
		del:function(key){
			window.sessionStorage.removeItem(key);
		},
		clear:function(key){
			window.sessionStorage.clear();
		}
	};
    var _peerId = '', _peerNum = 0, _totalP2PDownloaded = 0, _totalP2PUploaded = 0;
    const dp = new DPlayer({
      	theme: '#EE1289',
        container: document.getElementById('dplayer'),
        autoplay: true,
        allowfullscreen:true,
        //logo: '/owo/xxba/logo001.png',
        video: {
            url: '<?php echo $url ?>',
            type: 'customHls',
            pic: 'https://htoo.vip/owo/xxba/loading_wap.jpg',
            customType: {
                'customHls': function (video, player) {
                    const hls = new Hls({
                        debug: false,
                        p2pConfig: {
                            logLevel: 'debug',
                            live: false,        // 如果是直播设为true
                        }
                    });
                    hls.loadSource(video.src);
                    hls.attachMedia(video);
                    hls.p2pEngine.on('stats', function (stats) {
                        _totalP2PDownloaded = stats.totalP2PDownloaded;
                        _totalP2PUploaded = stats.totalP2PUploaded;
                        updateStats();
                    }).on('peerId', function (peerId) {
                        _peerId = peerId;
                    }).on('peers', function (peers) {
                        _peerNum = peers.length;
                        updateStats();
                    });

                }
            }
        }
    });
  dp.seek(webdata.get('pay<?php echo $url ?>'));
  setInterval(function(){
    webdata.set('pay<?php echo $url ?>',dp.video.currentTime);
  },1000);
  function updateStats() {
        var text = 'P2P加速' + (_totalP2PDownloaded/1024).toFixed(2)
            + 'MB 已分享' + (_totalP2PUploaded/1024).toFixed(2) + 'MB' + ' 节点' + _peerNum + '个';
        document.getElementById('stats').innerText = text
    }
</script>
<div id="a1" class="dplayer dplayer-no-danmaku">
<div class="dplayer-mask"></div>
<div id="ac_tips" class="fodong_box hidden-xs">
  <div class="fodong_tips">
    <ul style="margin-top: 0px; margin:0; padding:0; text-shadow: 0 0 3px rgb(0, 0, 0);">
    <li style="list-style: none;"><span class="font_zd">警告</span>不要相信视频中的广告，谨防上当受骗!</li>
    </ul>
  </div>
  <!--<a class="close_tips" href="javascript:void(0)">X</a>-->
</div>
</body>
</html>