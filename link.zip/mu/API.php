<?php
error_reporting(0);
header("content-type:text/json;charset=utf-8");
@$url = htmlspecialchars($_POST['url'] ? $_POST['url'] : $_GET['url']);
if ($url == "") {
    exit('请输入视频URL！');
}

$api='http://vip-jx-zhihu.mp4.fit/88619548%20jiexi.php?url=';
print_r(get_gc($api.$url));

function get_gc($url){
        $header = array(
            'User-Agent:Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_3 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5',
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $json = curl_exec($ch);
        curl_close($ch);

        return $json;
}
?>