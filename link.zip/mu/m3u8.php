<?php
error_reporting(0);
header("content-type:text/html;charset=utf-8");
if($_GET['url'] == ''){
    exit('<head>
    <meta charset="UTF-8">
    <title>DP播放器</title>
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico">
</head>
<style>
   *{  
    margin: 0px;  
    padding: 0px;  
    text-align: center;
    font-size: 16px;
    color: white;
    color: #03a9f4;
}
a{
    color: #ff9800;
}
body{
    width: 100%;
    background: #000;
}
table{
    margin: 0 auto;
}
</style>
<body>
    <h2 style="margin-top: 32px;color: red;">缺少视频地址，请输入URL地址___</h2>
    <p style="margin-top: 15px;">本Mao播放器全部免费,长期稳定,高清画质！可自己下载客户端搭建自己的Mao播放器！</p>
    <p style="margin-top: 15px;">Mao播放器测试地址： <a target="_blank" style="text-decoration: none; " href="https://www.mtosz.com/m3u8.php?url=">https://blog.longqiang.vip/mu/?url=</a></p>
    <p style="margin-top: 15px;"><font  style="color: red;">推荐使用：</font>高速客户端下载：<a target="_blank" style="text-decoration: none; " href="https://btjson.lanzoui.com/b0fefqsuj">点击下载</a></p><br> 
    <p>如在使用中有任何疑问，请联系管理员解决。Mao交流群：<a target="_blank" style="text-decoration: none; " href="https://t.me/BT_json">【（需科学上网）点我加群】</a><br><br>【<a target="_blank" style="text-decoration: none; " href="https://btjson.lanzoui.com/b0fdug87a">如果没有Telegram此聊天软件的点此下载</a>】【<a target="_blank" style="text-decoration: none;" href="https://btjson.lanzoui.com/b0fdug87a">或者点我百度官方下载</a>】<br>  <br>   
    此为Mao播放器演示</p><br><br>仅供内部交流研究，不以盈利为目的　切勿用于商业如有涉及商业请自行负责...</p><br>
   
    </table>
    <hr style="width: 60%;margin: 50px auto;" color="red">
</body>
</html>');
}
$url=$_GET['url'];
$nexturl=$_GET['next'];
$title=$_GET['title'];
if(empty($title)){
    $data=get_gc($url);
    $data = mb_convert_encoding($data, 'utf-8', 'GBK,UTF-8,ASCII');
    preg_match('|<title>(.*)</title>|isU',$data,$title);
   // $title =explode('-',$title[1])[0];//片名+集数
   $title =$title[1];//片名+集数+平台显示
}
$contextmenu='MaoPlayer';//右键名
$contextlink='https://jq.qq.com/?_wv=1027&k=vsFRmY2T';//地址链接
$background='https://s.pc.qq.com/tousu/img/20211103/8566961_1635917990.jpg';//播放器背景图
function get_gc($url){
        $header = array(
            'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36',
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $txt = curl_exec($ch);
        curl_close($ch);
        return $txt;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>MaoPlayer播放器</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="referrer" content="no-referrer">
    <meta http-equiv="Access-Control-Allow-Origin" content="*" />
    <meta http-equiv="Access-Control-Allow-Credentials" content="*" />
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
    <link rel="shortcut icon" href="https://cdn.jsdelivr.net/gh/IMGRU/IMG/2020/05/24/5eca62efd083f.png" type="image/x-icon">
    <link rel="stylesheet" href="./muiplayer/css/mui-player.min.css">
    <link rel="stylesheet" href="./muiplayer/css/muiplayer.css">
<style>
    body,html {
    	font: 24px 'Microsoft YaHei', Arial, Lucida Grande, Tahoma, sans-serif;
    	width: 100%;
    	height: 100%;
    	padding: 0;
    	margin: 0;
    	overflow-x: hidden;
    	overflow-y: hidden;
    	background-color: black;
    }
    #loading {
        background:url(https://img.zcool.cn/community/0120e15770d11d0000012e7e6f0859.gif);
        width: 100%;
        height: 100%;
        padding: 0;
        margin: 0;
        position: absolute;
        z-index: 10000000001;
        background-size: 100% 100%;
    }
    #error{
        background:url(<?php echo $background;?>);
        width: 100%;
        height: 100%;
        padding: 0;
        margin: 0;
        text-align:center;
        display:table; /*acts like a table*/
        position: absolute;
        z-index: 10000000001;
        background-size: 100% 100%; 
    }
    h1 {
        color: #ffffff;
        font-size: 1.2rem;
        margin:0;
        padding:0;
        vertical-align:middle; /*middle centred*/
        display:table-cell; /*acts like a table cell*/
        font-family: Microsoft Jhenghei;
    }
    </style>
    <script src="./muiplayer/js/jquery.min.js"></script>
    <script src="./muiplayer/js/mui-player.min.js"></script>
    <script src="./muiplayer/js/mui-player-desktop-plugin.min.js"></script>
    <script src="./muiplayer/js/mui-player-mobile-plugin.min.js"></script>
    <script src="./muiplayer/js/jquery.xctips.js"></script>
    <script src="./muiplayer/js/hls.min.js"></script>
    <script src="./muiplayer/js/flv.min.js"></script>
    <script src="./muiplayer/js/setting.js"></script>
</head>
<body>
    <div id="loading"  align="center"></div>
    <script type="text/javascript">
        var config = {
            "url": "<?php echo $url;?>",
            "title": "<?php echo $title;?>",
            "vkey": "<?php echo md5($url);?>",
            "next":"<?php echo $nexturl;?>",
            "contextmenu": "<?php echo $contextmenu;?>",
            "contextlink":"<?php echo $contextlink;?>",
            "background":"<?php echo $background;?>",
            "themeColor":"#FF69B4",
            "dragSpotShape":"square"
        };
        player(config);
    </script>
</body>
</html>